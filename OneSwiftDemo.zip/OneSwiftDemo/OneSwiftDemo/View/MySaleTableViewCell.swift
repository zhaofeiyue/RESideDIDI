//
//  MySaleTableViewCell.swift
//  OneSwiftDemo
//
//  Created by 赵飞跃 on 16/10/27.
//  Copyright © 2016年 赵飞跃. All rights reserved.
//

import UIKit

    protocol  YMCategoryBottomViewDelegate: NSObjectProtocol {
    func bottomViewButtonDidClicked()
}

class MySaleTableViewCell: UITableViewCell {
    weak var delegate: YMCategoryBottomViewDelegate?
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        // Initialization code
    }
    
    @IBOutlet weak var CheckoutDetailBtn: UIButton!

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func CheckDetailAction(sender: AnyObject) {
        let vc = MySaleViewController()
        self.delegate = vc
        if ((self.delegate?.respondsToSelector(Selector("bottomViewButtonDidClicked"))) != nil){
        
        delegate!.bottomViewButtonDidClicked()
        }
        
    }
}
