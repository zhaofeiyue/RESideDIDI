//
//  MySaleViewController.swift
//  OneSwiftDemo
//
//  Created by 赵飞跃 on 16/10/27.
//  Copyright © 2016年 赵飞跃. All rights reserved.
//

import UIKit

class MySaleViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,YMCategoryBottomViewDelegate{
    let cellId = "MySaleTableViewCell"
    var tabelView:UITableView?
    var dataSource:[String] = []
    
    static var width:CGFloat = UIScreen.mainScreen().bounds.size.width
    override func viewDidLoad() {
        
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.orangeColor()
        self.title = "我的售后"
        tabelView = UITableView(frame: CGRectMake(0, 0, UIScreen.mainScreen().bounds.size.width, UIScreen.mainScreen().bounds.size.height))
        tabelView?.delegate = self
        tabelView?.dataSource = self
        
        let nib0 = UINib.init(nibName:"MySaleTableViewCell",bundle: NSBundle.mainBundle())
        self.tabelView!.registerNib(nib0, forCellReuseIdentifier: "cell0")
        
        tabelView?.registerNib(nib0, forCellReuseIdentifier: "MySaleTableViewCell")
        self.view = tabelView
        //分割线左间隔为0
        if tabelView!.respondsToSelector("setSeparatorInset:"){
            tabelView?.separatorInset = UIEdgeInsetsZero
        }
        
        self.initData()
        tabelView?.reloadData()
        
        
        // Do any additional setup after loading the view.
    }
    //MySaleTableViewDelegate 代理实现
    func bottomViewButtonDidClicked() {
        print("hhaha")
        let vc = ViewController()
        self.presentViewController(vc, animated: true, completion: nil)
        presentViewController(vc, animated: true, completion: nil)
        
    }
    
    func initData(){
        for var i = 0; i < 10; ++i{
            dataSource.append("\(i)")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 225
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCellWithIdentifier(self.cellId, forIndexPath: indexPath) as! MySaleTableViewCell
        
//        let cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: nil)//此处的style不能用default, 否则detailLabel不显示
//        cell.textLabel?.text = dataSource[indexPath.row];
//       // cell.detailTextLabel?.textColor = UIColor.grayColor()
//        cell.detailTextLabel?.text = "game\(indexPath.row)"
        
//        cell.imageView?.image = UIImage(named: "img")
//        cell.imageView!.layer.cornerRadius = 10
//        cell.imageView!.layer.masksToBounds = true
        

        //把MySaleTableViewDelegate的代理社为self
        cell.delegate = self
        
        if cell.respondsToSelector("setSeparatorInset:"){
            cell.separatorInset = UIEdgeInsetsZero
        }
        
//        if cell.respondsToSelector("setLayoutMargins:"){
//            cell.layoutMargins = UIEdgeInsetsZero
//        }
        
        return cell
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
